from flask import Flask, render_template, request
from datetime import datetime

app = Flask(__name__)

@app.route('/', methods=['GET', 'POST'])
def index():
    result = None
    if request.method == 'POST':
        salary = float(request.form['salary'])
        goal_amount = float(request.form['goal_amount'])
        months_input = request.form['months_input']

        months_to_goal = 0
        if "year" in months_input.lower():
            months_to_goal = int(months_input.split()[0]) * 12
        elif "month" in months_input.lower():
            months_to_goal = int(months_input.split()[0])
        else:
            months_to_goal = int(months_input)

        monthly_goal = goal_amount / months_to_goal
        max_monthly_expenditure = salary - monthly_goal
        weeks_in_month = 4.34524
        days_in_month = 30
        max_weekly_expenditure = max_monthly_expenditure / weeks_in_month
        max_daily_expenditure = max_monthly_expenditure / days_in_month

        # After first part, get expenditure if submitted
        expenditure = float(request.form.get('expenditure', 0))
        savings = salary - expenditure
        status = "Congratulations! You have met or exceeded your monthly savings goal." if savings >= monthly_goal else "You are below your monthly savings target. Review your expenditures."

        now = datetime.now().strftime("%A, %B %d, %Y, %I:%M %p IST")
        result = {
            "goal_amount": goal_amount,
            "months_to_goal": months_to_goal,
            "monthly_goal": monthly_goal,
            "max_monthly_expenditure": max_monthly_expenditure,
            "max_weekly_expenditure": max_weekly_expenditure,
            "max_daily_expenditure": max_daily_expenditure,
            "salary": salary,
            "expenditure": expenditure,
            "savings": savings,
            "status": status,
            "now": now
        }

    return render_template("index.html", result=result)

if __name__ == '__main__':
    app.run(debug=True)
